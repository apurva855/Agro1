	<!DOCTYPE html>
	<html>
	<head>
		<title></title>
		<link rel="stylesheet" type="text/css" href="gallery.css">
	</head>
	<body>
		<main>
			<div class="box"><img src="images/banana-tree.jpg"></div>
			<div class="box"><img src="images/almond.jpg"></div>
			<div class="box"><img src="images/peanut.jpg"></div>
			<div class="box"><img src="images/beens.jpg"></div>
			<div class="box"><img src="images/jowar.jpg"></div>
			<div class="box"><img src="images/rice.jpg"></div>
			<div class="box"><img src="images/wheat1.jpg"></div>
			<div class="box"><img src="images/corn1.jpg"></div>
			<div class="box"><img src="images/red.jpg"></div>
			<div class="box"><img src="images/orange.jpg"></div>
			<div class="box"><img src="images/apple1.jpg"></div>
			<div class="box"><img src="images/cashew.jpg"></div>
		</main>
	
	</body>
	</html>