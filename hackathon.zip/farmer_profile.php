



<?php 

	$host = "localhost";
	$dbusername = "root";
	$dbpassword = "";
	$db = "digital farmer";

	//$conn =  mysqli_connect("$host","$dbusername","$dbpassword","$db");
	$conn =  new mysqli("$host","$dbusername","$dbpassword","$db");

	if($conn){
		echo"";
	}else{
		die("Connection failed: ".mysqli_connect_error());
	}

	//$userid = $_POST['userid'];

	$user = $_POST['username'];
	$sql="(SELECT * FROM farmer where userid='$user'  ) ";
	$result=mysqli_query($conn,$sql);

	//$result3 = mysqli_query($conn,"SELECT * FROM registration where username='$id'");
  
  	$row3 = mysqli_fetch_array($result);
		
		$id=$row3['id'];
		$name=$row3['name'];
		$address=$row3['address'];
		$contact=$row3['contact'];
		$userid=$row3['userid'];
		//$password=$row3['password'];
		
		echo "<h1> Your Profile  </h1>";
		echo "<p>Your ID is : </p> <br>".$id;	
		echo "<p>Your Name is : </p> <br>".$name;	
		echo "<p>Your Address is : </p> <br>".$address;	
		echo "<p> Contact Number is : </p> <br>".$contact;	
		echo "<p>User ID is : </p> <br>".$userid;	
	//$conn->close();

?>

	