<html>

	<head>
		<title> Farmer Home Page </title>
		<link rel="stylesheet" href="farmer_style.css">

		<meta charset="UTF-8">
		<meta name="description" content="Farmer page">
		<meta name="keywords" content="Digital Farmers,farmer">

	</head>
	<body>
		<div class="nav">
			<div>Farmers </div>
			<ul>
				<li><a href="farmer_home.html">Home</a></li>
				<li><a href="product.html">Sell Product </a></li>
				<li><a href="farmer_profile.html">My Profile </a></li>
				<li><a href="index.html">Logout</a></li>
				

			</ul>
			<html>

				<head>
					<title> </title>
					<link rel="stylesheet" type="text/css" href="search.css">
					<meta charset="UTF-8">
					<meta name="description" content="Farmer page">
					<meta name="keywords" content="Digital Farmers,farmer">

				</head>
				<body>
						<form class="search-form" action="search.php" method="post">
							<input type="text" name="prod_name" placeholer="search Product"required style="width: 300px; background-color: white; float: left;">
						<input type="submit" name ="search" style="width: 100px; background-color: grey; "></form>
					</div>
				</body>
			</html>
					<html>
				<head>
		<title></title>
		<link rel="stylesheet" type="text/css" href="gallery.css">
	</head>
	<body>
		<main>
			<div class="box"><img src="images/banana-tree.jpg"></div>
			<div class="box"><img src="images/almond.jpg"></div>
			<div class="box"><img src="images/peanut.jpg"></div>
			<div class="box"><img src="images/beens.jpg"></div>
			<div class="box"><img src="images/jowar.jpg"></div>
			<div class="box"><img src="images/rice.jpg"></div>
			<div class="box"><img src="images/wheat1.jpg"></div>
			<div class="box"><img src="images/corn1.jpg"></div>
			<div class="box"><img src="images/red.jpg"></div>
			<div class="box"><img src="images/orange.jpg"></div>
			<div class="box"><img src="images/apple1.jpg"></div>
			<div class="box"><img src="images/cashew.jpg"></div>
		</main>
	
	</body>
	</html>
	</body>
</html>
